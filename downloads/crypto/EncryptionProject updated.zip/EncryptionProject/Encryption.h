
#ifndef ENCRYPTION_H
#define ENCRYPTION_H

#include <string>

void encryptFile(const std::string& inputFile, const std::string& outputFile, const std::string& key, const std::string& method);
void decryptFile(const std::string& inputFile, const std::string& outputFile, const std::string& key, const std::string& method);

#endif

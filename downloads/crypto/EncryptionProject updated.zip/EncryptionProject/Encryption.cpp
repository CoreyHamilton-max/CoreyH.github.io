#include "Encryption.h"
#include <fstream>
#include <iostream>

void caesarEncryptDecrypt(std::string& data, int shift) {
    for (char &ch: data) {
        ch += shift; // NOLINT(*-narrowing-conversions)
    }


}

void xorEncryptDecrypt(std::string& data, const std::string& key) {
    for (size_t i = 0; i < data.size(); ++i) {
        data[i] ^= key[i % key.size()]; // NOLINT(*-narrowing-conversions)
    }


}

void processFile(const std::string& inputFile, const std::string& outputFile,
                 const std::string& key, const std::string& method, bool encrypt) {
    std::ifstream in(inputFile, std::ios::binary);
    std::ofstream out(outputFile, std::ios::binary);

    if (!in || !out) {
        std::cerr << "Error opening file(s)." << std::endl;
        return;
    }

    std::string data((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());

    if (method == "caesar") {
        caesarEncryptDecrypt(data, encrypt ? 3 : -3);
    } else if (method == "xor") {
        xorEncryptDecrypt(data, key);
    } else {
        std::cerr << "Invalid method!" << std::endl;
        return;
    }

    out << data;
}

void encryptFile(const std::string& inputFile, const std::string& outputFile,
                 const std::string& key, const std::string& method) {
    processFile(inputFile, outputFile, key, method, true);
}

void decryptFile(const std::string& inputFile, const std::string& outputFile,
                 const std::string& key, const std::string& method) {
    processFile(inputFile, outputFile, key, method, false);
}


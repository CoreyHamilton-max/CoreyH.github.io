#include "Database.h"
#include <sqlite3.h>
#include <iostream>

void logEncryption(const std::string& filename, const std::string& method, const std::string& status) {
    sqlite3* db;
    if (sqlite3_open("encryption_log.db", &db)) {
        std::cerr << "Cannot open database: " << sqlite3_errmsg(db) << std::endl;
        return;
    }

    const char* createTableSQL =
            "CREATE TABLE IF NOT EXISTS logs ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "filename TEXT, "
            "method TEXT, "
            "status TEXT, "
            "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP);";

    if (sqlite3_exec(db, createTableSQL, nullptr, nullptr, nullptr) != SQLITE_OK) {
        std::cerr << "Error creating table: " << sqlite3_errmsg(db) << std::endl;
    }

    std::string insertSQL = "INSERT INTO logs (filename, method, status) VALUES ('" +
                            filename + "', '" + method + "', '" + status + "');";

    if (sqlite3_exec(db, insertSQL.c_str(), nullptr, nullptr, nullptr) != SQLITE_OK) {
        std::cerr << "Error inserting record: " << sqlite3_errmsg(db) << std::endl;
    }

    sqlite3_close(db);
}

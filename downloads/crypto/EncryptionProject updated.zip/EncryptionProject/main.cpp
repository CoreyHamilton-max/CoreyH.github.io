#include "Encryption.h"
#include "Database.h"
#include <iostream>

int main(int argc, char* argv[]) {
    if (argc != 6) {
        std::cerr << "Usage: " << argv[0] << " <encrypt/decrypt> <inputFile> <outputFile> <method: caesar/xor> <key>" << std::endl;
        return 1;
    }

    std::string action = argv[1];
    std::string inputFile = argv[2];
    std::string outputFile = argv[3];
    std::string method = argv[4];
    std::string key = argv[5];

    if (action == "encrypt") {
        encryptFile(inputFile, outputFile, key, method);
        logEncryption(inputFile, method, "Success");
    } else if (action == "decrypt") {
        decryptFile(inputFile, outputFile, key, method);
        logEncryption(inputFile, method, "Success");
    } else {
        std::cerr << "Invalid action. Use 'encrypt' or 'decrypt'." << std::endl;
        return 1;
    }

    return 0;
}
